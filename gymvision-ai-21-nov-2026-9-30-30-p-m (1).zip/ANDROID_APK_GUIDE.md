# Guía para compilar GymVision AI como APK (Capacitor + Android Studio)

Este proyecto incluye toda la configuración de **Capacitor** (`capacitor.config.ts`) y la carpeta nativa `android/` lista para sincronizarse con Android Studio y generar un archivo `.apk`.

## 1. Requisitos en tu computadora
- **Node.js 20+**
- **Android Studio** (con Android SDK y JDK 17/21 incluidos)

## 2. Compilar y sincronizar la app web con Android
Cada vez que hagas cambios en el código React/TypeScript, ejecuta:

```bash
npm install
npm run android:sync
```

Esto ejecuta `vite build` (generando `dist/`) y sincroniza los archivos web, configuración y permisos con el proyecto `android/`.

## 3. Abrir en Android Studio y generar el APK
Abre el proyecto nativo directamente en Android Studio:

```bash
npm run android:open
```

Dentro de Android Studio:
1. Espera a que finalice **Gradle Sync**.
2. Para un **APK de prueba (Debug)** listo para instalar en tu teléfono:
   - Menú superior: **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
   - El archivo generado estará en: `android/app/build/outputs/apk/debug/app-debug.apk`.
3. Para un **APK / AAB firmado (Release / Play Store)**:
   - Menú superior: **Build → Generate Signed App Bundle / APK…** → selecciona **APK** → crea o elige tu Keystore → selecciona **release**.

También puedes generar el APK de prueba desde la terminal (con Java/Android SDK configurados):

```bash
npm run android:apk
```

## 4. Permisos nativos incluidos
El archivo `android/app/src/main/AndroidManifest.xml` ya está configurado con:
- `android.permission.CAMERA` (acceso a la cámara frontal y trasera para MediaPipe Pose)
- `android.permission.WAKE_LOCK` (mantener la pantalla encendida durante las series)
- `android.permission.INTERNET` (descarga inicial y caché del modelo MediaPipe Pose)

## 5. Compilación automática sin Android Studio (GitHub Actions)
Si subes este repositorio a GitHub, el workflow `.github/workflows/build-android-apk.yml` compila automáticamente el archivo `app-debug.apk` en la nube y lo publica como artefacto descargable (`GymVision-AI-APK`) en la pestaña **Actions**.
