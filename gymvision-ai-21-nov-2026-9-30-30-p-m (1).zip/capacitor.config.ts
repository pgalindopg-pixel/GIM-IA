import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.gymvision.ai',
  appName: 'GymVision AI',
  webDir: 'dist',
  server: {
    androidScheme: 'https',
    cleartext: false,
  },
  android: {
    backgroundColor: '#090d16',
    allowMixedContent: false,
    captureInput: true,
    webContentsDebuggingEnabled: false,
  },
  plugins: {
    SplashScreen: {
      backgroundColor: '#090d16',
      launchShowDuration: 1200,
      showSpinner: false,
    },
    StatusBar: {
      backgroundColor: '#090d16',
      style: 'DARK',
    },
  },
};

export default config;
