import React, { useCallback, useEffect, useRef, useState } from 'react';
import { FilesetResolver, PoseLandmarker } from '@mediapipe/tasks-vision';
import {
  Pause,
  Play,
  RefreshCw,
  Save,
  Volume2,
  VolumeX,
  X,
  Zap,
} from 'lucide-react';
import { CameraViewport } from './components/CameraViewport';
import { HistoryPanel } from './components/HistoryPanel';
import { MetricsPanel } from './components/MetricsPanel';
import { OfflineIndicator, PWAInstallCard } from './components/PWAInstallBanner';
import { SettingsPanel } from './components/SettingsPanel';
import {
  AUDIO_MODE_LABELS,
  AppSettings,
  AudioMode,
  DEFAULT_SETTINGS,
  EXERCISE_CONFIG,
  ExerciseId,
  LiveTelemetry,
  ModelStatus,
  WorkoutPhase,
  WorkoutRecord,
} from './types/workout';
import {
  computePaceRPM,
  ensureAudioContext,
  formatDuration,
  loadHistory,
  loadSettings,
  playRepBeep,
  saveHistory,
  saveSettings,
  triggerRepFeedback,
} from './utils/audioAndStorage';
import {
  TrackerRuntime,
  createInitialTrackerRuntime,
  drawPoseSkeleton,
  evaluateBurpeesFrame,
  evaluateKettlebellSwingsFrame,
} from './utils/poseEngine';

type UtilityTab = 'history' | 'settings';

const MEDIAPIPE_WASM_ROOT =
  'https://cdn.jsdelivr.net/npm/@mediapipe/tasks-vision@1.2.3/wasm';
const POSE_MODEL_URL =
  'https://storage.googleapis.com/mediapipe-models/pose_landmarker/pose_landmarker_lite/float16/1/pose_landmarker_lite.task';

function getInitialTelemetry(exercise: ExerciseId): LiveTelemetry {
  return exercise === 'kettlebell_swings'
    ? {
        line1: 'Ángulo cadera: --°',
        line2: 'Muñecas: --',
        visibilityText: 'Sin cuerpo',
        visibilityTone: 'missing',
      }
    : {
        line1: 'Bajada cadera: --%',
        line2: 'Torso: --°',
        visibilityText: 'Sin cuerpo',
        visibilityTone: 'missing',
      };
}

function KettlebellIcon({ className }: { className?: string }) {
  return (
    <svg
      className={className}
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2.2"
      strokeLinecap="round"
      strokeLinejoin="round"
      aria-hidden="true"
    >
      <path d="M9 7V5a3 3 0 0 1 6 0v2" />
      <path d="M6.5 9.5a6.5 6.5 0 1 0 11 0 4.5 4.5 0 0 0-3.5-2h-4a4.5 4.5 0 0 0-3.5 2z" />
    </svg>
  );
}

export default function App() {
  // Persisted state
  const [settings, setSettings] = useState<AppSettings>(() => loadSettings());
  const [history, setHistory] = useState<WorkoutRecord[]>(() => loadHistory());

  // Live session UI state
  const [modelStatus, setModelStatus] = useState<ModelStatus>('loading');
  const [cameraActive, setCameraActive] = useState(false);
  const [cameraStarting, setCameraStarting] = useState(false);
  const [cameraError, setCameraError] = useState<string | null>(null);
  const [wakeLockActive, setWakeLockActive] = useState(false);

  const [repCount, setRepCount] = useState(0);
  const [repPulseKey, setRepPulseKey] = useState(0);
  const [lastRepDurationMs, setLastRepDurationMs] = useState<number | null>(null);
  const [elapsedSeconds, setElapsedSeconds] = useState(0);
  const [timerRunning, setTimerRunning] = useState(false);

  const [phase, setPhase] = useState<WorkoutPhase>(() =>
    settings.exercise === 'burpees' ? 'B_STANDING' : 'KB_READY'
  );
  const [fps, setFps] = useState(0);
  const [telemetry, setTelemetry] = useState<LiveTelemetry>(() =>
    getInitialTelemetry(settings.exercise)
  );

  // Utility panels & toast
  const [activeUtilityTab, setActiveUtilityTab] = useState<UtilityTab>('history');
  const [mobilePanelOpen, setMobilePanelOpen] = useState<UtilityTab | null>(null);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  // Refs for real-time 60fps detection loop without re-renders
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const poseLandmarkerRef = useRef<PoseLandmarker | null>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const rafIdRef = useRef<number | null>(null);
  const wakeLockRef = useRef<WakeLockSentinel | null>(null);

  const settingsRef = useRef<AppSettings>(settings);
  const cameraActiveRef = useRef(cameraActive);
  const timerRunningRef = useRef(timerRunning);
  const repCountRef = useRef(repCount);
  const elapsedSecondsRef = useRef(elapsedSeconds);
  const trackerRef = useRef<TrackerRuntime>(createInitialTrackerRuntime(settings.exercise));
  const lastVideoTimeRef = useRef(-1);
  const lastFrameTimeRef = useRef(0);
  const fpsSmoothRef = useRef(0);
  const lastHudSyncRef = useRef(0);
  const toastTimerRef = useRef<number | null>(null);

  // Keep refs synced with state
  useEffect(() => {
    settingsRef.current = settings;
    saveSettings(settings);
  }, [settings]);

  useEffect(() => {
    cameraActiveRef.current = cameraActive;
  }, [cameraActive]);

  useEffect(() => {
    timerRunningRef.current = timerRunning;
  }, [timerRunning]);

  useEffect(() => {
    repCountRef.current = repCount;
  }, [repCount]);

  useEffect(() => {
    elapsedSecondsRef.current = elapsedSeconds;
  }, [elapsedSeconds]);

  // Toast helper
  const showToast = useCallback((msg: string) => {
    setToastMessage(msg);
    if (toastTimerRef.current) {
      window.clearTimeout(toastTimerRef.current);
    }
    toastTimerRef.current = window.setTimeout(() => {
      setToastMessage(null);
    }, 4500);
  }, []);

  // Wake Lock API
  const requestWakeLock = useCallback(async () => {
    try {
      if ('wakeLock' in navigator && !wakeLockRef.current) {
        const sentinel = await navigator.wakeLock.request('screen');
        wakeLockRef.current = sentinel;
        setWakeLockActive(true);
        sentinel.addEventListener('release', () => {
          wakeLockRef.current = null;
          setWakeLockActive(false);
        });
      }
    } catch {
      // Wake Lock not available in this context
    }
  }, []);

  const releaseWakeLock = useCallback(async () => {
    try {
      if (wakeLockRef.current) {
        await wakeLockRef.current.release();
        wakeLockRef.current = null;
        setWakeLockActive(false);
      }
    } catch {
      // Ignore release errors
    }
  }, []);

  // Workout timer interval
  useEffect(() => {
    if (!timerRunning) return;
    const id = window.setInterval(() => {
      setElapsedSeconds((prev) => prev + 1);
    }, 1000);
    return () => window.clearInterval(id);
  }, [timerRunning]);

  // Initialize MediaPipe PoseLandmarker (GPU with automatic CPU fallback)
  const initPoseLandmarker = useCallback(async (): Promise<PoseLandmarker | null> => {
    if (poseLandmarkerRef.current) return poseLandmarkerRef.current;
    setModelStatus('loading');
    try {
      const vision = await FilesetResolver.forVisionTasks(MEDIAPIPE_WASM_ROOT);
      let landmarker: PoseLandmarker;
      try {
        landmarker = await PoseLandmarker.createFromOptions(vision, {
          baseOptions: {
            modelAssetPath: POSE_MODEL_URL,
            delegate: 'GPU',
          },
          runningMode: 'VIDEO',
          numPoses: 1,
          minPoseDetectionConfidence: 0.45,
          minPosePresenceConfidence: 0.45,
          minTrackingConfidence: 0.45,
        });
      } catch {
        // Fallback to CPU delegate if WebGL/GPU delegate is unavailable
        landmarker = await PoseLandmarker.createFromOptions(vision, {
          baseOptions: {
            modelAssetPath: POSE_MODEL_URL,
            delegate: 'CPU',
          },
          runningMode: 'VIDEO',
          numPoses: 1,
          minPoseDetectionConfidence: 0.45,
          minPosePresenceConfidence: 0.45,
          minTrackingConfidence: 0.45,
        });
      }
      poseLandmarkerRef.current = landmarker;
      setModelStatus('ready');
      return landmarker;
    } catch (err) {
      console.error('Error inicializando MediaPipe Pose Landmarker:', err);
      setModelStatus('error');
      showToast('No se pudo cargar MediaPipe Pose. Verifica tu conexión a internet.');
      return null;
    }
  }, [showToast]);

  // Preload model on mount
  useEffect(() => {
    void initPoseLandmarker();
  }, [initPoseLandmarker]);

  // Stop raw camera stream & RAF loop
  const stopCameraStreamOnly = useCallback(() => {
    if (rafIdRef.current !== null) {
      cancelAnimationFrame(rafIdRef.current);
      rafIdRef.current = null;
    }
    if (streamRef.current) {
      streamRef.current.getTracks().forEach((track) => track.stop());
      streamRef.current = null;
    }
    if (videoRef.current) {
      videoRef.current.srcObject = null;
    }
  }, []);

  // Main real-time pose detection loop
  const runDetectionLoop = useCallback(() => {
    if (!cameraActiveRef.current) return;

    const now = performance.now();
    const deltaMs = Math.max(1, now - lastFrameTimeRef.current);
    lastFrameTimeRef.current = now;
    const instantFps = 1000 / deltaMs;
    fpsSmoothRef.current =
      fpsSmoothRef.current === 0
        ? instantFps
        : fpsSmoothRef.current * 0.85 + instantFps * 0.15;

    const video = videoRef.current;
    const canvas = canvasRef.current;
    const landmarker = poseLandmarkerRef.current;
    const currentSettings = settingsRef.current;

    try {
      if (
        landmarker &&
        video &&
        canvas &&
        video.readyState >= 2 &&
        video.currentTime !== lastVideoTimeRef.current
      ) {
        lastVideoTimeRef.current = video.currentTime;
        const results = landmarker.detectForVideo(video, now);

        if (results.landmarks && results.landmarks.length > 0) {
          const landmarks = results.landmarks[0];
          const evaluation =
            currentSettings.exercise === 'burpees'
              ? evaluateBurpeesFrame(
                  landmarks,
                  trackerRef.current,
                  currentSettings.confidenceThreshold,
                  currentSettings.sensitivityLevel,
                  now
                )
              : evaluateKettlebellSwingsFrame(
                  landmarks,
                  trackerRef.current,
                  currentSettings.confidenceThreshold,
                  currentSettings.sensitivityLevel,
                  now
                );

          if (evaluation.bodyDetected && !timerRunningRef.current && cameraActiveRef.current) {
            timerRunningRef.current = true;
            setTimerRunning(true);
          }

          if (evaluation.phaseChanged) {
            setPhase(evaluation.nextPhase);
          }

          if (evaluation.repCompleted) {
            const nextRep = repCountRef.current + 1;
            repCountRef.current = nextRep;
            setRepCount(nextRep);
            setRepPulseKey((k) => k + 1);
            if (evaluation.repDurationMs !== null) {
              setLastRepDurationMs(evaluation.repDurationMs);
            }
            triggerRepFeedback(nextRep, currentSettings.audioMode, currentSettings.exercise);
          }

          // Throttle HUD text updates to ~10 Hz to keep React ultra-smooth
          if (now - lastHudSyncRef.current > 100) {
            lastHudSyncRef.current = now;
            setFps(Math.round(fpsSmoothRef.current));
            setTelemetry(evaluation.telemetry);
          }

          drawPoseSkeleton(
            canvas,
            video,
            landmarks,
            trackerRef.current.phase,
            currentSettings.confidenceThreshold,
            currentSettings.drawSkeleton
          );
        } else {
          if (now - lastHudSyncRef.current > 150) {
            lastHudSyncRef.current = now;
            setFps(Math.round(fpsSmoothRef.current));
            setTelemetry(getInitialTelemetry(currentSettings.exercise));
          }
          drawPoseSkeleton(
            canvas,
            video,
            null,
            trackerRef.current.phase,
            currentSettings.confidenceThreshold,
            currentSettings.drawSkeleton
          );
        }
      }
    } catch (err) {
      console.warn('Advertencia de detección:', err);
    }

    rafIdRef.current = requestAnimationFrame(runDetectionLoop);
  }, []);

  const startCamera = useCallback(
    async (overrideFacing?: 'user' | 'environment') => {
      ensureAudioContext();
      if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
        setCameraError('Tu navegador no soporta acceso a la cámara.');
        showToast('Tu navegador no soporta acceso a la cámara.');
        return;
      }

      setCameraStarting(true);
      setCameraError(null);

      try {
        stopCameraStreamOnly();
        const facing = overrideFacing ?? settingsRef.current.facingMode;
        const stream = await navigator.mediaDevices.getUserMedia({
          audio: false,
          video: {
            facingMode: { ideal: facing },
            width: { ideal: 640 },
            height: { ideal: 480 },
          },
        });
        streamRef.current = stream;

        const video = videoRef.current;
        if (!video) throw new Error('Video element unavailable');
        video.srcObject = stream;

        await new Promise<void>((resolve, reject) => {
          video.onloadedmetadata = () => resolve();
          video.onerror = () => reject(new Error('Error cargando stream de video'));
        });
        await video.play();

        if (!poseLandmarkerRef.current) {
          await initPoseLandmarker();
        }

        cameraActiveRef.current = true;
        setCameraActive(true);
        lastVideoTimeRef.current = -1;
        lastFrameTimeRef.current = performance.now();
        fpsSmoothRef.current = 0;

        await requestWakeLock();
        rafIdRef.current = requestAnimationFrame(runDetectionLoop);
      } catch (err) {
        console.error('Error al iniciar cámara:', err);
        cameraActiveRef.current = false;
        setCameraActive(false);
        setCameraError(
          'Activa los permisos de cámara en tu navegador o prueba cambiar entre cámara frontal y trasera.'
        );
        showToast('No se pudo acceder a la cámara.');
      } finally {
        setCameraStarting(false);
      }
    },
    [initPoseLandmarker, requestWakeLock, runDetectionLoop, showToast, stopCameraStreamOnly]
  );

  const stopCamera = useCallback(async () => {
    cameraActiveRef.current = false;
    setCameraActive(false);
    stopCameraStreamOnly();
    timerRunningRef.current = false;
    setTimerRunning(false);
    setFps(0);
    await releaseWakeLock();

    const canvas = canvasRef.current;
    if (canvas) {
      const ctx = canvas.getContext('2d');
      ctx?.clearRect(0, 0, canvas.width, canvas.height);
    }
  }, [releaseWakeLock, stopCameraStreamOnly]);

  // Archive active set to history
  const archiveCurrentSet = useCallback(
    (silent: boolean): boolean => {
      const reps = repCountRef.current;
      const duration = elapsedSecondsRef.current;
      if (reps <= 0 && duration <= 0) return false;

      const ex = settingsRef.current.exercise;
      const cfg = EXERCISE_CONFIG[ex];
      const entry: WorkoutRecord = {
        id: `${Date.now()}-${Math.random().toString(36).slice(2, 7)}`,
        timestamp: new Date().toISOString(),
        exercise: ex,
        exerciseName: cfg.name,
        reps,
        durationSec: duration,
        paceRpm: computePaceRPM(reps, duration),
      };

      setHistory((prev) => {
        const updated = [entry, ...prev].slice(0, 60);
        saveHistory(updated);
        return updated;
      });

      if (!silent) {
        showToast(
          `Guardado: ${entry.reps} ${entry.exerciseName} en ${formatDuration(
            entry.durationSec
          )} (${entry.paceRpm.toFixed(1)} RPM).`
        );
      }
      return true;
    },
    [showToast]
  );

  const resetActiveWorkout = useCallback((exercise: ExerciseId) => {
    timerRunningRef.current = false;
    setTimerRunning(false);
    repCountRef.current = 0;
    setRepCount(0);
    elapsedSecondsRef.current = 0;
    setElapsedSeconds(0);
    setLastRepDurationMs(null);
    trackerRef.current = createInitialTrackerRuntime(exercise);
    setPhase(trackerRef.current.phase);
    setTelemetry(getInitialTelemetry(exercise));
  }, []);

  const handleSaveAndReset = useCallback(() => {
    const saved = archiveCurrentSet(false);
    if (!saved) {
      showToast('Contador reiniciado a 0.');
    }
    resetActiveWorkout(settingsRef.current.exercise);
  }, [archiveCurrentSet, resetActiveWorkout, showToast]);

  const handleSwitchExercise = useCallback(
    (nextExercise: ExerciseId) => {
      if (settingsRef.current.exercise === nextExercise) return;
      if (repCountRef.current > 0) {
        archiveCurrentSet(true);
      }
      setSettings((prev) => ({ ...prev, exercise: nextExercise }));
      resetActiveWorkout(nextExercise);
    },
    [archiveCurrentSet, resetActiveWorkout]
  );

  const handleSwitchCameraFacing = useCallback(async () => {
    const nextFacing = settingsRef.current.facingMode === 'user' ? 'environment' : 'user';
    setSettings((prev) => ({ ...prev, facingMode: nextFacing }));
    if (cameraActiveRef.current) {
      await startCamera(nextFacing);
    }
  }, [startCamera]);

  const handleCycleAudioMode = useCallback(() => {
    const order: AudioMode[] = ['both', 'voice', 'beep', 'off'];
    const currentIdx = order.indexOf(settingsRef.current.audioMode);
    const nextMode = order[(currentIdx + 1) % order.length];
    setSettings((prev) => ({ ...prev, audioMode: nextMode }));
    if (nextMode !== 'off') {
      playRepBeep();
    }
  }, []);

  const handleUpdateSettings = useCallback((patch: Partial<AppSettings>) => {
    setSettings((prev) => ({ ...prev, ...patch }));
  }, []);

  const handleResetCalibrationDefaults = useCallback(() => {
    setSettings((prev) => ({
      ...prev,
      sensitivityLevel: DEFAULT_SETTINGS.sensitivityLevel,
      confidenceThreshold: DEFAULT_SETTINGS.confidenceThreshold,
      audioMode: DEFAULT_SETTINGS.audioMode,
      drawSkeleton: DEFAULT_SETTINGS.drawSkeleton,
    }));
    showToast('Ajustes restaurados a valores predeterminados.');
  }, [showToast]);

  const handleDeleteHistoryEntry = useCallback((id: string) => {
    setHistory((prev) => {
      const updated = prev.filter((item) => item.id !== id);
      saveHistory(updated);
      return updated;
    });
  }, []);

  const handleClearHistory = useCallback(() => {
    setHistory([]);
    saveHistory([]);
    showToast('Historial borrado.');
  }, [showToast]);

  // Handle tab visibility changes & cleanup on unmount
  useEffect(() => {
    const handleVisibility = async () => {
      if (document.hidden && cameraActiveRef.current) {
        timerRunningRef.current = false;
        setTimerRunning(false);
      } else if (!document.hidden && cameraActiveRef.current) {
        await requestWakeLock();
        if (repCountRef.current > 0) {
          timerRunningRef.current = true;
          setTimerRunning(true);
        }
      }
    };
    document.addEventListener('visibilitychange', handleVisibility);
    return () => {
      document.removeEventListener('visibilitychange', handleVisibility);
    };
  }, [requestWakeLock]);

  useEffect(() => {
    return () => {
      stopCameraStreamOnly();
      void releaseWakeLock();
      if (toastTimerRef.current) window.clearTimeout(toastTimerRef.current);
      if (poseLandmarkerRef.current) {
        poseLandmarkerRef.current.close();
        poseLandmarkerRef.current = null;
      }
    };
  }, [releaseWakeLock, stopCameraStreamOnly]);

  const handleHeaderNav = (target: 'workout' | UtilityTab) => {
    if (target === 'workout') {
      setMobilePanelOpen(null);
      window.scrollTo({ top: 0, behavior: 'smooth' });
      return;
    }
    setActiveUtilityTab(target);
    setMobilePanelOpen((prev) => (prev === target ? null : target));
  };

  const isBurpees = settings.exercise === 'burpees';

  return (
    <div className="gym-canvas-bg min-h-screen flex flex-col text-slate-100">
      {/* Compact 3-Zone Top Bar */}
      <header className="sticky top-0 z-30 h-14 backdrop-blur-md bg-obsidian/90 border-b border-slate-800/80 px-4 sm:px-6">
        <div className="max-w-7xl mx-auto h-full flex items-center justify-between gap-4 sm:gap-8">
          {/* Zone 1: Single-line Brand Wordmark */}
          <a
            href="#entrenamiento"
            onClick={(e) => {
              e.preventDefault();
              handleHeaderNav('workout');
            }}
            className="font-display text-2xl font-extrabold tracking-tight text-white whitespace-nowrap shrink-0"
          >
            GYMVISION AI
          </a>

          {/* Zone 2: Clean Single-Line Nav Links */}
          <nav
            aria-label="Navegación principal"
            className="flex items-center gap-4 sm:gap-7 text-xs sm:text-sm font-semibold text-slate-400"
          >
            <button
              type="button"
              onClick={() => handleHeaderNav('workout')}
              className={`min-h-[40px] hover:text-white transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                mobilePanelOpen === null ? 'text-white' : ''
              }`}
            >
              Entrenar
            </button>
            <button
              type="button"
              onClick={() => handleHeaderNav('history')}
              className={`min-h-[40px] hover:text-white transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                activeUtilityTab === 'history' || mobilePanelOpen === 'history'
                  ? 'text-cyber'
                  : ''
              }`}
            >
              Historial ({history.length})
            </button>
            <button
              type="button"
              onClick={() => handleHeaderNav('settings')}
              className={`min-h-[40px] hover:text-white transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                activeUtilityTab === 'settings' || mobilePanelOpen === 'settings'
                  ? 'text-volt'
                  : ''
              }`}
            >
              Ajustes
            </button>
          </nav>

          {/* Zone 3: Single Primary Action */}
          <div className="shrink-0">
            <button
              type="button"
              disabled={cameraStarting}
              onClick={() => (cameraActive ? void stopCamera() : void startCamera())}
              className={`min-h-[40px] px-4 py-2 rounded-xl text-xs sm:text-sm font-extrabold transition cursor-pointer whitespace-nowrap shrink-0 ${
                cameraActive
                  ? 'bg-slate-800 hover:bg-slate-700 text-white border border-slate-700'
                  : 'bg-volt hover:bg-lime-300 text-obsidian'
              }`}
            >
              {cameraActive ? 'Pausar' : 'Iniciar'}
            </button>
          </div>
        </div>
      </header>

      {/* Non-blocking Toast Banner */}
      {toastMessage && (
        <div
          role="status"
          aria-live="polite"
          className="fixed top-16 left-1/2 -translate-x-1/2 z-50 w-[92%] max-w-md px-4 py-3 rounded-2xl bg-slate-900/95 border border-volt/50 shadow-2xl text-sm text-slate-100 flex items-center justify-between gap-3 backdrop-blur-md"
        >
          <span className="leading-snug font-medium">{toastMessage}</span>
          <button
            type="button"
            onClick={() => setToastMessage(null)}
            aria-label="Cerrar notificación"
            className="min-h-[36px] min-w-[36px] flex items-center justify-center rounded-lg text-volt hover:bg-volt/10 shrink-0 cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      {/* Main Responsive Workspace: Mobile Single Column -> Desktop 12-Col Athletic Studio */}
      <main
        id="entrenamiento"
        className="flex-1 w-full max-w-7xl mx-auto px-3.5 sm:px-6 py-4 sm:py-6"
      >
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-4 sm:gap-6 items-start">
          {/* Primary Camera & Controls Column */}
          <div className="lg:col-span-7 xl:col-span-8 space-y-3.5 sm:space-y-4">
            {/* Prominent Exercise Mode Segmented Selector */}
            <section
              aria-label="Selector de ejercicio"
              className="rounded-2xl bg-panel border border-slate-800/90 p-1.5 grid grid-cols-2 gap-1.5"
            >
              <button
                type="button"
                onClick={() => handleSwitchExercise('burpees')}
                aria-pressed={isBurpees}
                className={`min-h-[46px] px-3 py-2.5 rounded-xl font-extrabold text-xs sm:text-sm tracking-wide flex items-center justify-center gap-2 transition cursor-pointer whitespace-nowrap ${
                  isBurpees
                    ? 'bg-volt text-obsidian'
                    : 'bg-transparent text-slate-300 hover:bg-slate-800/70 hover:text-white'
                }`}
              >
                <Zap className="w-4 h-4 shrink-0" aria-hidden="true" />
                <span>Burpees</span>
              </button>

              <button
                type="button"
                onClick={() => handleSwitchExercise('kettlebell_swings')}
                aria-pressed={!isBurpees}
                className={`min-h-[46px] px-3 py-2.5 rounded-xl font-extrabold text-xs sm:text-sm tracking-wide flex items-center justify-center gap-2 transition cursor-pointer whitespace-nowrap ${
                  !isBurpees
                    ? 'bg-cyber text-obsidian'
                    : 'bg-transparent text-slate-300 hover:bg-slate-800/70 hover:text-white'
                }`}
              >
                <KettlebellIcon className="w-4 h-4 shrink-0" />
                <span>Kettlebell Swings</span>
              </button>
            </section>

            {/* Mobile-only Metrics directly above Camera so reps remain immediately visible */}
            <div className="lg:hidden">
              <MetricsPanel
                exercise={settings.exercise}
                repCount={repCount}
                repPulseKey={repPulseKey}
                elapsedSeconds={elapsedSeconds}
                timerRunning={timerRunning}
                wakeLockActive={wakeLockActive}
                cameraActive={cameraActive}
                lastRepDurationMs={lastRepDurationMs}
              />
            </div>

            {/* Live Camera & Skeleton Viewport */}
            <CameraViewport
              videoRef={videoRef}
              canvasRef={canvasRef}
              exercise={settings.exercise}
              phase={phase}
              facingMode={settings.facingMode}
              cameraActive={cameraActive}
              cameraStarting={cameraStarting}
              cameraError={cameraError}
              modelStatus={modelStatus}
              fps={fps}
              telemetry={telemetry}
              onStartCamera={() => void startCamera()}
            />

            {/* Primary Action Controls Dock (48px touch targets) */}
            <section
              aria-label="Controles de entrenamiento"
              className="grid grid-cols-2 sm:grid-cols-4 gap-2.5"
            >
              <button
                type="button"
                disabled={cameraStarting}
                onClick={() => (cameraActive ? void stopCamera() : void startCamera())}
                className={`min-h-[48px] px-4 py-3 rounded-xl font-extrabold text-sm flex items-center justify-center gap-2 active:scale-[0.98] transition cursor-pointer whitespace-nowrap ${
                  cameraActive
                    ? 'bg-surface hover:bg-slate-700/80 text-white border border-slate-700'
                    : 'bg-volt hover:bg-lime-300 text-obsidian'
                }`}
              >
                {cameraActive ? (
                  <Pause className="w-4 h-4 shrink-0" aria-hidden="true" />
                ) : (
                  <Play className="w-4 h-4 shrink-0" aria-hidden="true" />
                )}
                <span>{cameraActive ? 'Pausar' : 'Iniciar'}</span>
              </button>

              <button
                type="button"
                onClick={() => void handleSwitchCameraFacing()}
                className="min-h-[48px] px-4 py-3 rounded-xl bg-surface hover:bg-slate-700/80 active:scale-[0.98] text-white border border-slate-800 font-bold text-sm flex items-center justify-center gap-2 transition cursor-pointer whitespace-nowrap"
              >
                <RefreshCw className="w-4 h-4 text-cyber shrink-0" aria-hidden="true" />
                <span>{settings.facingMode === 'user' ? 'Cám. Frontal' : 'Cám. Trasera'}</span>
              </button>

              <button
                type="button"
                onClick={handleCycleAudioMode}
                className="min-h-[48px] px-4 py-3 rounded-xl bg-surface hover:bg-slate-700/80 active:scale-[0.98] text-white border border-slate-800 font-bold text-sm flex items-center justify-center gap-2 transition cursor-pointer whitespace-nowrap"
              >
                {settings.audioMode === 'off' ? (
                  <VolumeX className="w-4 h-4 text-slate-400 shrink-0" aria-hidden="true" />
                ) : (
                  <Volume2 className="w-4 h-4 text-volt shrink-0" aria-hidden="true" />
                )}
                <span className="truncate">{AUDIO_MODE_LABELS[settings.audioMode]}</span>
              </button>

              <button
                type="button"
                onClick={handleSaveAndReset}
                className="min-h-[48px] px-4 py-3 rounded-xl bg-ember/15 hover:bg-ember/25 active:scale-[0.98] text-ember border border-ember/40 font-extrabold text-sm flex items-center justify-center gap-2 transition cursor-pointer whitespace-nowrap"
              >
                <Save className="w-4 h-4 shrink-0" aria-hidden="true" />
                <span>Guardar / Reset</span>
              </button>
            </section>

            {/* Mobile Collapsible Settings / History Drawer */}
            {mobilePanelOpen === 'settings' && (
              <div className="lg:hidden">
                <SettingsPanel
                  settings={settings}
                  onUpdateSettings={handleUpdateSettings}
                  onResetDefaults={handleResetCalibrationDefaults}
                />
              </div>
            )}

            {mobilePanelOpen === 'history' && (
              <div className="lg:hidden">
                <HistoryPanel
                  history={history}
                  onDeleteEntry={handleDeleteHistoryEntry}
                  onClearHistory={handleClearHistory}
                />
              </div>
            )}

            {/* In-App Install / Android APK Guide Card (auto-hides once installed) */}
            <PWAInstallCard />
          </div>

          {/* Desktop Right Rail: Live Metrics + Tabbed History / Settings */}
          <aside className="hidden lg:flex lg:col-span-5 xl:col-span-4 flex-col gap-4">
            <MetricsPanel
              exercise={settings.exercise}
              repCount={repCount}
              repPulseKey={repPulseKey}
              elapsedSeconds={elapsedSeconds}
              timerRunning={timerRunning}
              wakeLockActive={wakeLockActive}
              cameraActive={cameraActive}
              lastRepDurationMs={lastRepDurationMs}
            />

            {/* Segmented Switcher for History & Settings */}
            <div className="rounded-xl bg-panel border border-slate-800/90 p-1 grid grid-cols-2 gap-1">
              <button
                type="button"
                onClick={() => setActiveUtilityTab('history')}
                className={`min-h-[42px] rounded-lg text-xs font-bold transition cursor-pointer whitespace-nowrap ${
                  activeUtilityTab === 'history'
                    ? 'bg-surface text-white'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                Historial ({history.length})
              </button>
              <button
                type="button"
                onClick={() => setActiveUtilityTab('settings')}
                className={`min-h-[42px] rounded-lg text-xs font-bold transition cursor-pointer whitespace-nowrap ${
                  activeUtilityTab === 'settings'
                    ? 'bg-surface text-white'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                Sensibilidad y audio
              </button>
            </div>

            {activeUtilityTab === 'history' ? (
              <HistoryPanel
                history={history}
                onDeleteEntry={handleDeleteHistoryEntry}
                onClearHistory={handleClearHistory}
              />
            ) : (
              <SettingsPanel
                settings={settings}
                onUpdateSettings={handleUpdateSettings}
                onResetDefaults={handleResetCalibrationDefaults}
              />
            )}
          </aside>
        </div>
      </main>

      {/* Quiet Footer */}
      <footer className="border-t border-slate-800/70 px-4 sm:px-6 py-3.5 text-xs text-slate-400">
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-start sm:items-center justify-between gap-2">
          <span>
            Vista lateral o a 45° mejora la precisión de cadera, rodillas y muñecas.
          </span>
          <span className="font-mono text-slate-500">
            Detección local en el dispositivo · MediaPipe Pose
          </span>
        </div>
      </footer>
      {/* Offline Connectivity Toast */}
      <OfflineIndicator />
    </div>
  );
}
