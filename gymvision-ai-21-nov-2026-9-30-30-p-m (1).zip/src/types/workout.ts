export type ExerciseId = 'burpees' | 'kettlebell_swings';

export type AudioMode = 'both' | 'voice' | 'beep' | 'off';

export type CameraFacingMode = 'user' | 'environment';

export type SensitivityLevel = 1 | 2 | 3;

export type BurpeePhase =
  | 'B_STANDING'
  | 'B_SQUAT_DROP'
  | 'B_PLANK_FLOOR'
  | 'B_ASCEND'
  | 'B_JUMP_FINISH';

export type KettlebellPhase = 'KB_READY' | 'KB_HINGE' | 'KB_DRIVE';

export type WorkoutPhase = BurpeePhase | KettlebellPhase;

export type ModelStatus = 'loading' | 'ready' | 'error';

export type VisibilityTone = 'ok' | 'partial' | 'missing';

export interface PhaseStepConfig {
  id: WorkoutPhase;
  short: string;
  label: string;
  accentHex: string;
  dotClass: string;
  borderClass: string;
}

export interface ExerciseConfigItem {
  id: ExerciseId;
  name: string;
  shortTag: string;
  tipText: string;
  phaseHeader: string;
  steps: PhaseStepConfig[];
}

export interface AppSettings {
  exercise: ExerciseId;
  sensitivityLevel: SensitivityLevel;
  confidenceThreshold: number;
  audioMode: AudioMode;
  drawSkeleton: boolean;
  facingMode: CameraFacingMode;
}

export interface WorkoutRecord {
  id: string;
  timestamp: string;
  exercise: ExerciseId;
  exerciseName: string;
  reps: number;
  durationSec: number;
  paceRpm: number;
}

export interface LiveTelemetry {
  line1: string;
  line2: string;
  visibilityText: string;
  visibilityTone: VisibilityTone;
}

export interface DynamicThresholds {
  burpeeDropRatio: number;
  burpeeFloorTorsoMaxDeg: number;
  burpeeStandMargin: number;
  kbHingeMaxDeg: number;
  kbLockoutMinDeg: number;
  kbWristDriveRatio: number;
}

export const STORAGE_KEYS = {
  HISTORY: 'gymvision_ai_history_v2',
  SETTINGS: 'gymvision_ai_settings_v2',
} as const;

export const DEFAULT_SETTINGS: AppSettings = {
  exercise: 'burpees',
  sensitivityLevel: 2,
  confidenceThreshold: 0.45,
  audioMode: 'both',
  drawSkeleton: true,
  facingMode: 'user',
};

export const EXERCISE_CONFIG: Record<ExerciseId, ExerciseConfigItem> = {
  burpees: {
    id: 'burpees',
    name: 'Burpees',
    shortTag: 'Burpees',
    tipText:
      'Apoya el teléfono de perfil a 2–3 metros para que se vea todo tu cuerpo (de cabeza a pies) al bajar a plancha y saltar.',
    phaseHeader: 'Fase Burpee',
    steps: [
      {
        id: 'B_STANDING',
        short: '1. De pie',
        label: '1. De pie (Inicio)',
        accentHex: '#a3e635',
        dotClass: 'bg-volt',
        borderClass: 'border-volt/40',
      },
      {
        id: 'B_SQUAT_DROP',
        short: '2. Bajada',
        label: '2. Sentadilla / Bajada',
        accentHex: '#22d3ee',
        dotClass: 'bg-cyber',
        borderClass: 'border-cyber/40',
      },
      {
        id: 'B_PLANK_FLOOR',
        short: '3. Suelo',
        label: '3. Plancha / Suelo',
        accentHex: '#fb7185',
        dotClass: 'bg-rose-400',
        borderClass: 'border-rose-400/50',
      },
      {
        id: 'B_ASCEND',
        short: '4. Subida',
        label: '4. Subida',
        accentHex: '#fbbf24',
        dotClass: 'bg-amber-400',
        borderClass: 'border-amber-400/40',
      },
      {
        id: 'B_JUMP_FINISH',
        short: '5. Salto',
        label: '5. Salto / Extensión',
        accentHex: '#fb923c',
        dotClass: 'bg-ember',
        borderClass: 'border-ember/50',
      },
    ],
  },
  kettlebell_swings: {
    id: 'kettlebell_swings',
    name: 'Kettlebell Swings',
    shortTag: 'KB Swings',
    tipText:
      'Coloca el teléfono de lado o en ángulo de 45° para detectar con precisión la bisagra de cadera y el recorrido de las muñecas.',
    phaseHeader: 'Fase KB Swing',
    steps: [
      {
        id: 'KB_READY',
        short: '1. Inicio',
        label: '1. Posición inicial',
        accentHex: '#a3e635',
        dotClass: 'bg-volt',
        borderClass: 'border-volt/40',
      },
      {
        id: 'KB_HINGE',
        short: '2. Bisagra',
        label: '2. Bisagra de cadera',
        accentHex: '#22d3ee',
        dotClass: 'bg-cyber',
        borderClass: 'border-cyber/45',
      },
      {
        id: 'KB_DRIVE',
        short: '3. Impulso',
        label: '3. Impulso / Extensión',
        accentHex: '#fb923c',
        dotClass: 'bg-ember',
        borderClass: 'border-ember/50',
      },
    ],
  },
};

export const SENSITIVITY_LABELS: Record<SensitivityLevel, string> = {
  1: 'Baja (estricto)',
  2: 'Media',
  3: 'Alta (flexible)',
};

export const AUDIO_MODE_LABELS: Record<AudioMode, string> = {
  both: 'Voz + Pitido',
  voice: 'Solo Voz',
  beep: 'Solo Pitido',
  off: 'Silenciado',
};
