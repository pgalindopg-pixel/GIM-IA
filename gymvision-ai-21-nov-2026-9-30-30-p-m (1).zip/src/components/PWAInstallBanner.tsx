import React, { useState } from 'react';
import { Download, Smartphone, WifiOff, X } from 'lucide-react';
import { useOnlineStatus, usePWAInstall } from '../hooks/usePWAInstall';

export const PWAInstallCard: React.FC = () => {
  const { isInstallable, isInstalled, isIOS, install } = usePWAInstall();
  const [showGuideModal, setShowGuideModal] = useState(false);

  if (isInstalled) {
    return null;
  }

  return (
    <>
      <section
        aria-label="Instalar en Android o móvil"
        className="rounded-2xl bg-panel border border-slate-800/90 px-4 py-3.5 flex flex-col sm:flex-row sm:items-center justify-between gap-3"
      >
        <div className="min-w-0">
          <div className="text-sm font-bold text-white flex items-center gap-2">
            <Smartphone className="w-4 h-4 text-volt shrink-0" aria-hidden="true" />
            <span>Instalar GymVision en tu teléfono</span>
          </div>
          <p className="text-xs text-slate-400 mt-0.5 leading-relaxed">
            {isInstallable
              ? 'Instálala directo en tu pantalla de inicio en pantalla completa y con soporte sin conexión.'
              : isIOS
                ? 'Agrégala a la pantalla de inicio desde Safari para usarla como aplicación nativa.'
                : 'Lista para instalarse como app en Android (Chrome) o empaquetarse como archivo APK.'}
          </p>
        </div>

        <div className="flex items-center gap-2 shrink-0">
          {isInstallable ? (
            <button
              type="button"
              onClick={() => void install()}
              className="min-h-[44px] px-4 py-2 rounded-xl bg-volt hover:bg-lime-300 active:scale-[0.98] text-obsidian text-xs sm:text-sm font-extrabold flex items-center gap-2 transition cursor-pointer whitespace-nowrap"
            >
              <Download className="w-4 h-4 shrink-0" aria-hidden="true" />
              <span>Instalar App</span>
            </button>
          ) : (
            <button
              type="button"
              onClick={() => setShowGuideModal(true)}
              className="min-h-[44px] px-4 py-2 rounded-xl bg-surface hover:bg-slate-700/80 active:scale-[0.98] text-white border border-slate-700 text-xs sm:text-sm font-bold flex items-center gap-2 transition cursor-pointer whitespace-nowrap"
            >
              <Download className="w-4 h-4 text-volt shrink-0" aria-hidden="true" />
              <span>{isIOS ? 'Instalar en iOS' : 'Cómo instalar / APK'}</span>
            </button>
          )}
        </div>
      </section>

      {showGuideModal && (
        <div
          role="dialog"
          aria-modal="true"
          aria-labelledby="pwa-guide-title"
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 backdrop-blur-sm p-4"
        >
          <div className="w-full max-w-md rounded-3xl bg-panel border border-slate-800 p-5 sm:p-6 space-y-4">
            <div className="flex items-center justify-between gap-3">
              <h3 id="pwa-guide-title" className="text-base sm:text-lg font-bold text-white">
                {isIOS ? 'Instalar en iPhone / iPad' : 'Instalar en Android o generar APK'}
              </h3>
              <button
                type="button"
                onClick={() => setShowGuideModal(false)}
                aria-label="Cerrar"
                className="min-h-[40px] min-w-[40px] flex items-center justify-center rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {isIOS ? (
              <ol className="text-sm text-slate-300 space-y-2.5 list-decimal list-inside leading-relaxed">
                <li>
                  Toca el botón <strong className="text-white">Compartir</strong> en la barra de
                  Safari.
                </li>
                <li>
                  Desliza hacia abajo y elige{' '}
                  <strong className="text-white">Añadir a pantalla de inicio</strong>.
                </li>
                <li>
                  Pulsa <strong className="text-white">Añadir</strong> para abrir GymVision en
                  pantalla completa.
                </li>
              </ol>
            ) : (
              <div className="space-y-3 text-sm text-slate-300 leading-relaxed">
                <div>
                  <p className="font-bold text-volt text-xs mb-1">
                    Opción 1 · Instalación directa en Android (sin PC)
                  </p>
                  <p className="text-xs text-slate-300">
                    Abre la URL pública en <strong className="text-white">Google Chrome</strong>,
                    toca el menú <strong className="text-white">⋮</strong> y selecciona{' '}
                    <strong className="text-white">Instalar aplicación</strong>.
                  </p>
                </div>
                <div className="border-t border-slate-800 pt-3">
                  <p className="font-bold text-cyber text-xs mb-1">
                    Opción 2 · Archivo .APK descargable
                  </p>
                  <p className="text-xs text-slate-300">
                    Pega la URL desplegada en <strong className="text-white">PWABuilder.com</strong>{' '}
                    para generar el paquete Android APK/AAB automáticamente, o compila el proyecto
                    con el flujo incluido de <strong className="text-white">Capacitor</strong>{' '}
                    (GitHub Actions o Android Studio).
                  </p>
                </div>
              </div>
            )}

            <button
              type="button"
              onClick={() => setShowGuideModal(false)}
              className="w-full min-h-[44px] rounded-xl bg-volt hover:bg-lime-300 text-obsidian font-extrabold text-sm transition cursor-pointer"
            >
              Entendido
            </button>
          </div>
        </div>
      )}
    </>
  );
};

export const OfflineIndicator: React.FC = () => {
  const isOnline = useOnlineStatus();
  if (isOnline) return null;

  return (
    <div
      role="status"
      className="fixed bottom-4 left-4 z-50 flex items-center gap-2 rounded-xl bg-amber-500 px-3.5 py-2 text-xs font-bold text-obsidian shadow-lg"
    >
      <WifiOff className="w-4 h-4 shrink-0" aria-hidden="true" />
      <span>Modo sin conexión — usando caché local</span>
    </div>
  );
};
