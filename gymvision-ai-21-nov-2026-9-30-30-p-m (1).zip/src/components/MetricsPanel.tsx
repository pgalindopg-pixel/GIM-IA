import React from 'react';
import { EXERCISE_CONFIG, ExerciseId } from '../types/workout';
import { computePaceRPM, formatDuration } from '../utils/audioAndStorage';

interface MetricsPanelProps {
  exercise: ExerciseId;
  repCount: number;
  repPulseKey: number;
  elapsedSeconds: number;
  timerRunning: boolean;
  wakeLockActive: boolean;
  cameraActive: boolean;
  lastRepDurationMs: number | null;
}

export const MetricsPanel: React.FC<MetricsPanelProps> = ({
  exercise,
  repCount,
  repPulseKey,
  elapsedSeconds,
  timerRunning,
  wakeLockActive,
  cameraActive,
  lastRepDurationMs,
}) => {
  const cfg = EXERCISE_CONFIG[exercise];
  const paceRpm = computePaceRPM(repCount, elapsedSeconds).toFixed(1);
  const accentTextClass = exercise === 'kettlebell_swings' ? 'text-cyber' : 'text-volt';

  const repSubtext =
    lastRepDurationMs !== null
      ? `Última rep: ${(lastRepDurationMs / 1000).toFixed(1)}s`
      : cameraActive
        ? 'Detectando movimiento...'
        : 'Listo para contar';

  return (
    <section aria-label="Métricas en vivo" className="space-y-3">
      {/* Primary Metrics Strip */}
      <div className="grid grid-cols-3 lg:grid-cols-2 gap-2.5 sm:gap-3">
        {/* Giant Rep Counter (Full-width focal metric on Desktop right rail, 1/3 on Mobile) */}
        <div className="lg:col-span-2 rounded-2xl bg-panel border border-slate-800/90 p-3.5 sm:p-5 flex flex-col justify-between">
          <div className="flex items-center justify-between gap-2 text-xs">
            <span className={`font-bold tracking-wide ${accentTextClass}`}>Repeticiones</span>
            <span className="font-mono text-slate-400 truncate">{cfg.shortTag}</span>
          </div>

          <div
            key={repPulseKey}
            className={`font-mono tabular-nums text-4xl sm:text-5xl lg:text-7xl font-extrabold text-white tracking-tight leading-none mt-2 ${
              repCount > 0 ? 'rep-celebrate' : ''
            }`}
          >
            {repCount}
          </div>

          <div className="text-xs text-slate-400 mt-2 truncate">{repSubtext}</div>
        </div>

        {/* Elapsed Timer */}
        <div className="rounded-2xl bg-panel border border-slate-800/90 p-3.5 sm:p-4 flex flex-col justify-between">
          <div className="flex items-center justify-between gap-1 text-xs">
            <span className="font-bold text-cyber">Tiempo</span>
            <span
              className={`font-mono text-[11px] ${
                timerRunning ? 'text-volt font-bold' : 'text-slate-400'
              }`}
            >
              {timerRunning ? 'Activo' : 'Pausa'}
            </span>
          </div>

          <div className="font-mono tabular-nums text-2xl sm:text-3xl font-extrabold text-white tracking-tight mt-1.5">
            {formatDuration(elapsedSeconds)}
          </div>

          <div
            className={`text-[11px] sm:text-xs mt-1.5 truncate ${
              wakeLockActive ? 'text-volt' : 'text-slate-400'
            }`}
          >
            {wakeLockActive ? 'Pantalla activa' : 'Duración serie'}
          </div>
        </div>

        {/* Pace (RPM) */}
        <div className="rounded-2xl bg-panel border border-slate-800/90 p-3.5 sm:p-4 flex flex-col justify-between">
          <div className="flex items-center justify-between gap-1 text-xs">
            <span className="font-bold text-ember">Ritmo</span>
            <span className="font-mono text-[11px] text-slate-400">RPM</span>
          </div>

          <div className="font-mono tabular-nums text-2xl sm:text-3xl font-extrabold text-white tracking-tight mt-1.5">
            {paceRpm}
          </div>

          <div className="text-[11px] sm:text-xs text-slate-400 mt-1.5 truncate">
            Reps / minuto
          </div>
        </div>
      </div>

      {/* Positioning Guidance (clean unboxed border card, no thick left bar or pill badge) */}
      <div className="rounded-2xl bg-surface/75 border border-slate-800/90 px-4 py-3 text-xs sm:text-sm text-slate-300 leading-relaxed">
        <span className={`font-bold ${accentTextClass} mr-1.5`}>Guía de encuadre:</span>
        {cfg.tipText}
      </div>
    </section>
  );
};
