import React from 'react';
import { Camera } from 'lucide-react';
import {
  CameraFacingMode,
  EXERCISE_CONFIG,
  ExerciseId,
  LiveTelemetry,
  ModelStatus,
  WorkoutPhase,
} from '../types/workout';

interface CameraViewportProps {
  videoRef: React.RefObject<HTMLVideoElement | null>;
  canvasRef: React.RefObject<HTMLCanvasElement | null>;
  exercise: ExerciseId;
  phase: WorkoutPhase;
  facingMode: CameraFacingMode;
  cameraActive: boolean;
  cameraStarting: boolean;
  cameraError: string | null;
  modelStatus: ModelStatus;
  fps: number;
  telemetry: LiveTelemetry;
  onStartCamera: () => void;
}

export const CameraViewport: React.FC<CameraViewportProps> = ({
  videoRef,
  canvasRef,
  exercise,
  phase,
  facingMode,
  cameraActive,
  cameraStarting,
  cameraError,
  modelStatus,
  fps,
  telemetry,
  onStartCamera,
}) => {
  const cfg = EXERCISE_CONFIG[exercise];
  const activeStep = cfg.steps.find((s) => s.id === phase) ?? cfg.steps[0];
  const isMirrored = facingMode === 'user';
  const stepperColsClass = cfg.steps.length === 5 ? 'grid-cols-5' : 'grid-cols-3';

  const visibilityColorClass =
    telemetry.visibilityTone === 'ok'
      ? exercise === 'kettlebell_swings'
        ? 'text-cyber'
        : 'text-volt'
      : telemetry.visibilityTone === 'partial'
        ? 'text-amber-300'
        : 'text-slate-400';

  const modelStatusLabel =
    modelStatus === 'ready'
      ? 'MediaPipe listo'
      : modelStatus === 'loading'
        ? 'Cargando modelo IA...'
        : 'Error de carga IA';

  return (
    <section
      aria-label="Cámara y detección de pose"
      className="relative w-full rounded-3xl overflow-hidden bg-slate-950 border border-slate-800/90 aspect-[3/4] sm:aspect-[16/10] max-h-[62vh] lg:max-h-[68vh]"
    >
      <video
        ref={videoRef}
        playsInline
        muted
        autoPlay
        className={`w-full h-full object-cover bg-slate-950 ${isMirrored ? 'mirrored-media' : ''}`}
      />
      <canvas
        ref={canvasRef}
        className={`absolute inset-0 w-full h-full pointer-events-none ${isMirrored ? 'mirrored-media' : ''}`}
      />

      {/* Top Contrast Scrim & Live HUD */}
      <div className="absolute inset-x-0 top-0 bg-gradient-to-b from-black/80 via-black/45 to-transparent p-3 sm:p-4 pointer-events-none z-10">
        <div className="flex items-start justify-between gap-3">
          {/* Active Phase Readout */}
          <div className="min-w-0 max-w-[58%]">
            <div className="flex items-center gap-2 text-xs text-slate-300">
              <span
                className="inline-block w-2 h-2 rounded-full shrink-0"
                style={{ backgroundColor: activeStep.accentHex }}
                aria-hidden="true"
              />
              <span className="font-semibold tracking-wide truncate">{cfg.phaseHeader}</span>
            </div>
            <div className="text-sm sm:text-base font-bold text-white tracking-tight truncate mt-0.5">
              {activeStep.label}
            </div>
          </div>

          {/* Live Biomechanical Telemetry */}
          <div className="text-right font-mono tabular-nums shrink-0">
            <div className="text-xs sm:text-sm font-bold text-cyber leading-snug">
              {telemetry.line1}
            </div>
            <div className="text-[11px] sm:text-xs text-slate-200 leading-snug">
              {telemetry.line2}
            </div>
            <div className="mt-1 flex items-center justify-end gap-1.5 text-[11px] font-sans">
              <span className="font-mono text-slate-300">{fps > 0 ? `${fps} FPS` : '-- FPS'}</span>
              <span className="text-slate-500" aria-hidden="true">
                ·
              </span>
              <span className={`font-semibold ${visibilityColorClass}`}>
                {telemetry.visibilityText}
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* Bottom Contrast Scrim & Dynamic Phase Stepper */}
      <div className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-black/85 via-black/45 to-transparent p-3 sm:p-4 pointer-events-none z-10">
        <div
          className={`grid ${stepperColsClass} gap-1.5 bg-obsidian/80 backdrop-blur-md border border-slate-800/90 rounded-2xl p-1.5`}
        >
          {cfg.steps.map((step) => {
            const isActive = step.id === phase;
            return (
              <div
                key={step.id}
                className={`rounded-xl py-1.5 px-1.5 text-center text-[11px] sm:text-xs font-bold truncate transition-colors ${
                  isActive
                    ? exercise === 'kettlebell_swings'
                      ? 'bg-cyber text-obsidian'
                      : 'bg-volt text-obsidian'
                    : 'bg-slate-900/70 text-slate-400'
                }`}
              >
                {step.short}
              </div>
            );
          })}
        </div>
      </div>

      {/* Camera Inactive / Loading Overlay */}
      {!cameraActive && (
        <div className="absolute inset-0 z-20 bg-slate-950/92 backdrop-blur-sm flex flex-col items-center justify-center p-6 text-center">
          <div className="w-14 h-14 rounded-2xl bg-volt/12 border border-volt/30 flex items-center justify-center mb-4">
            <Camera className="w-7 h-7 text-volt" aria-hidden="true" />
          </div>

          <h2 className="font-display text-2xl sm:text-3xl font-extrabold tracking-tight text-white mb-2 text-balance">
            {cameraStarting
              ? 'Iniciando cámara e IA...'
              : cameraError
                ? 'Acceso a cámara bloqueado'
                : 'Configuración de cámara'}
          </h2>

          <p className="text-sm text-slate-300 max-w-md mb-2 leading-relaxed">
            {cameraStarting
              ? 'Concede permiso de cámara cuando el navegador lo solicite.'
              : cameraError
                ? cameraError
                : 'Apoya el teléfono de perfil a 2–3 metros para que se vea tu cuerpo completo. Presiona Iniciar cámara para comenzar.'}
          </p>

          <p className="text-xs text-slate-400 mb-6 font-mono tabular-nums">{modelStatusLabel}</p>

          <button
            type="button"
            disabled={cameraStarting}
            onClick={onStartCamera}
            className="min-h-[48px] px-7 py-3 rounded-xl bg-volt hover:bg-lime-300 active:scale-[0.98] disabled:opacity-60 text-obsidian font-extrabold text-sm tracking-wide transition cursor-pointer whitespace-nowrap"
          >
            {cameraStarting ? 'Conectando...' : 'Iniciar cámara'}
          </button>
        </div>
      )}
    </section>
  );
};
