import type { NormalizedLandmark } from '@mediapipe/tasks-vision';
import {
  DynamicThresholds,
  ExerciseId,
  LiveTelemetry,
  SensitivityLevel,
  WorkoutPhase,
} from '../types/workout';

// MediaPipe Pose Landmark Indices
export const LM = {
  NOSE: 0,
  LEFT_SHOULDER: 11,
  RIGHT_SHOULDER: 12,
  LEFT_ELBOW: 13,
  RIGHT_ELBOW: 14,
  LEFT_WRIST: 15,
  RIGHT_WRIST: 16,
  LEFT_HIP: 23,
  RIGHT_HIP: 24,
  LEFT_KNEE: 25,
  RIGHT_KNEE: 26,
  LEFT_ANKLE: 27,
  RIGHT_ANKLE: 28,
} as const;

export const SKELETON_CONNECTIONS: ReadonlyArray<[number, number]> = [
  [LM.LEFT_SHOULDER, LM.RIGHT_SHOULDER],
  [LM.LEFT_SHOULDER, LM.LEFT_ELBOW],
  [LM.LEFT_ELBOW, LM.LEFT_WRIST],
  [LM.RIGHT_SHOULDER, LM.RIGHT_ELBOW],
  [LM.RIGHT_ELBOW, LM.RIGHT_WRIST],
  [LM.LEFT_SHOULDER, LM.LEFT_HIP],
  [LM.RIGHT_SHOULDER, LM.RIGHT_HIP],
  [LM.LEFT_HIP, LM.RIGHT_HIP],
  [LM.LEFT_HIP, LM.LEFT_KNEE],
  [LM.LEFT_KNEE, LM.LEFT_ANKLE],
  [LM.RIGHT_HIP, LM.RIGHT_KNEE],
  [LM.RIGHT_KNEE, LM.RIGHT_ANKLE],
];

const TRACKED_JOINT_INDICES = [
  LM.LEFT_SHOULDER,
  LM.RIGHT_SHOULDER,
  LM.LEFT_ELBOW,
  LM.RIGHT_ELBOW,
  LM.LEFT_WRIST,
  LM.RIGHT_WRIST,
  LM.LEFT_HIP,
  LM.RIGHT_HIP,
  LM.LEFT_KNEE,
  LM.RIGHT_KNEE,
  LM.LEFT_ANKLE,
  LM.RIGHT_ANKLE,
];

interface Point2D {
  x: number;
  y: number;
  z: number;
  visibility: number;
}

export interface TrackerRuntime {
  phase: WorkoutPhase;
  phaseEnteredAt: number;
  repStartTime: number | null;
  lastRepCompletedAt: number;
  // Burpees state
  reachedFloor: boolean;
  standingHipY: number | null;
  standingShoulderY: number | null;
  calibrationSamples: Array<{ hipY: number; shoulderY: number }>;
  // Kettlebell Swings state
  hingePeakConfirmed: boolean;
  minHingeAngleSeen: number;
}

export interface FrameEvaluationResult {
  phaseChanged: boolean;
  nextPhase: WorkoutPhase;
  repCompleted: boolean;
  repDurationMs: number | null;
  bodyDetected: boolean;
  telemetry: LiveTelemetry;
}

export function createInitialTrackerRuntime(exercise: ExerciseId): TrackerRuntime {
  return {
    phase: exercise === 'burpees' ? 'B_STANDING' : 'KB_READY',
    phaseEnteredAt: performance.now(),
    repStartTime: null,
    lastRepCompletedAt: 0,
    reachedFloor: false,
    standingHipY: null,
    standingShoulderY: null,
    calibrationSamples: [],
    hingePeakConfirmed: false,
    minHingeAngleSeen: 180,
  };
}

export function getDynamicThresholds(level: SensitivityLevel): DynamicThresholds {
  if (level === 1) {
    return {
      burpeeDropRatio: 0.2,
      burpeeFloorTorsoMaxDeg: 32,
      burpeeStandMargin: 0.03,
      kbHingeMaxDeg: 118,
      kbLockoutMinDeg: 166,
      kbWristDriveRatio: 0.3,
    };
  }
  if (level === 3) {
    return {
      burpeeDropRatio: 0.12,
      burpeeFloorTorsoMaxDeg: 48,
      burpeeStandMargin: 0.06,
      kbHingeMaxDeg: 134,
      kbLockoutMinDeg: 156,
      kbWristDriveRatio: 0.15,
    };
  }
  return {
    burpeeDropRatio: 0.16,
    burpeeFloorTorsoMaxDeg: 40,
    burpeeStandMargin: 0.045,
    kbHingeMaxDeg: 125,
    kbLockoutMinDeg: 162,
    kbWristDriveRatio: 0.22,
  };
}

function getValidPoint(
  landmarks: NormalizedLandmark[],
  idx: number,
  minVis: number
): Point2D | null {
  const lm = landmarks[idx];
  if (!lm) return null;
  const vis = lm.visibility !== undefined ? lm.visibility : 1.0;
  if (vis < minVis) return null;
  return { x: lm.x, y: lm.y, z: lm.z || 0, visibility: vis };
}

function midpoint(p1: Point2D | null, p2: Point2D | null): Point2D | null {
  if (p1 && p2) {
    return {
      x: (p1.x + p2.x) * 0.5,
      y: (p1.y + p2.y) * 0.5,
      z: (p1.z + p2.z) * 0.5,
      visibility: Math.min(p1.visibility, p2.visibility),
    };
  }
  return p1 || p2 || null;
}

export function calculateAngleDegrees(
  a: Point2D | null,
  b: Point2D | null,
  c: Point2D | null
): number | null {
  if (!a || !b || !c) return null;
  const abX = a.x - b.x;
  const abY = a.y - b.y;
  const cbX = c.x - b.x;
  const cbY = c.y - b.y;
  const dot = abX * cbX + abY * cbY;
  const magAB = Math.hypot(abX, abY);
  const magCB = Math.hypot(cbX, cbY);
  if (magAB === 0 || magCB === 0) return null;
  const cosAngle = Math.max(-1, Math.min(1, dot / (magAB * magCB)));
  return (Math.acos(cosAngle) * 180) / Math.PI;
}

export function calculateTorsoHorizontalAngle(
  shoulder: Point2D | null,
  hip: Point2D | null
): number | null {
  if (!shoulder || !hip) return null;
  const dx = Math.abs(shoulder.x - hip.x);
  const dy = Math.abs(shoulder.y - hip.y);
  return (Math.atan2(dy, Math.max(0.0001, dx)) * 180) / Math.PI;
}

export function evaluateBurpeesFrame(
  landmarks: NormalizedLandmark[],
  runtime: TrackerRuntime,
  minVis: number,
  sensitivity: SensitivityLevel,
  now: number
): FrameEvaluationResult {
  const th = getDynamicThresholds(sensitivity);
  const shoulder = midpoint(
    getValidPoint(landmarks, LM.LEFT_SHOULDER, minVis),
    getValidPoint(landmarks, LM.RIGHT_SHOULDER, minVis)
  );
  const hip = midpoint(
    getValidPoint(landmarks, LM.LEFT_HIP, minVis),
    getValidPoint(landmarks, LM.RIGHT_HIP, minVis)
  );
  const knee = midpoint(
    getValidPoint(landmarks, LM.LEFT_KNEE, minVis),
    getValidPoint(landmarks, LM.RIGHT_KNEE, minVis)
  );
  const ankle = midpoint(
    getValidPoint(landmarks, LM.LEFT_ANKLE, minVis),
    getValidPoint(landmarks, LM.RIGHT_ANKLE, minVis)
  );

  if (!shoulder || !hip) {
    return {
      phaseChanged: false,
      nextPhase: runtime.phase,
      repCompleted: false,
      repDurationMs: null,
      bodyDetected: false,
      telemetry: {
        line1: 'Bajada Cadera: --%',
        line2: 'Torso: --°',
        visibilityText: 'Entra al cuadro',
        visibilityTone: 'missing',
      },
    };
  }

  const fullBody = Boolean(knee && ankle);
  const torsoAngleDeg = calculateTorsoHorizontalAngle(shoulder, hip) ?? 90;
  const torsoSpanY = Math.abs(hip.y - shoulder.y);

  // Calibración dinámica de altura de pie
  if (runtime.phase === 'B_STANDING' && torsoAngleDeg > 62 && torsoSpanY > 0.14) {
    runtime.calibrationSamples.push({ hipY: hip.y, shoulderY: shoulder.y });
    if (runtime.calibrationSamples.length > 24) {
      runtime.calibrationSamples.shift();
    }
    const avgHip =
      runtime.calibrationSamples.reduce((a, b) => a + b.hipY, 0) /
      runtime.calibrationSamples.length;
    const avgShoulder =
      runtime.calibrationSamples.reduce((a, b) => a + b.shoulderY, 0) /
      runtime.calibrationSamples.length;

    if (runtime.standingHipY === null || runtime.standingShoulderY === null) {
      runtime.standingHipY = avgHip;
      runtime.standingShoulderY = avgShoulder;
    } else {
      runtime.standingHipY = runtime.standingHipY * 0.85 + avgHip * 0.15;
      runtime.standingShoulderY = runtime.standingShoulderY * 0.85 + avgShoulder * 0.15;
    }
  }

  const visibilityText = fullBody ? 'Cuerpo completo' : 'Torso detectado';
  const visibilityTone = fullBody ? 'ok' : 'partial';

  if (runtime.standingHipY === null || runtime.standingShoulderY === null) {
    return {
      phaseChanged: false,
      nextPhase: runtime.phase,
      repCompleted: false,
      repDurationMs: null,
      bodyDetected: true,
      telemetry: {
        line1: 'Calibrando pie...',
        line2: `Torso: ${Math.round(torsoAngleDeg)}°`,
        visibilityText,
        visibilityTone,
      },
    };
  }

  const hipDrop = hip.y - runtime.standingHipY;
  const shoulderDrop = shoulder.y - runtime.standingShoulderY;

  const telemetry: LiveTelemetry = {
    line1: `Bajada cadera: ${Math.round(hipDrop * 100)}%`,
    line2: `Torso: ${Math.round(torsoAngleDeg)}°`,
    visibilityText,
    visibilityTone,
  };

  // Reiniciar ciclo atascado (>12s)
  if (
    runtime.repStartTime &&
    now - runtime.repStartTime > 12000 &&
    runtime.phase !== 'B_STANDING'
  ) {
    runtime.repStartTime = null;
    runtime.reachedFloor = false;
    runtime.phase = 'B_STANDING';
    runtime.phaseEnteredAt = now;
    return {
      phaseChanged: true,
      nextPhase: 'B_STANDING',
      repCompleted: false,
      repDurationMs: null,
      bodyDetected: true,
      telemetry,
    };
  }

  const prevPhase = runtime.phase;
  let repCompleted = false;
  let repDurationMs: number | null = null;

  switch (runtime.phase) {
    case 'B_STANDING': {
      if (hipDrop >= th.burpeeDropRatio * 0.7 || shoulderDrop >= th.burpeeDropRatio * 0.85) {
        runtime.repStartTime = now;
        runtime.reachedFloor = false;
        runtime.phase = 'B_SQUAT_DROP';
        runtime.phaseEnteredAt = now;
      }
      break;
    }
    case 'B_SQUAT_DROP': {
      const isHorizontalOrFloor =
        torsoAngleDeg <= th.burpeeFloorTorsoMaxDeg ||
        (hipDrop >= th.burpeeDropRatio && shoulderDrop >= th.burpeeDropRatio * 1.15);
      if (isHorizontalOrFloor) {
        runtime.reachedFloor = true;
        runtime.phase = 'B_PLANK_FLOOR';
        runtime.phaseEnteredAt = now;
      } else if (hipDrop < th.burpeeDropRatio * 0.25 && now - runtime.phaseEnteredAt > 1800) {
        runtime.repStartTime = null;
        runtime.reachedFloor = false;
        runtime.phase = 'B_STANDING';
        runtime.phaseEnteredAt = now;
      }
      break;
    }
    case 'B_PLANK_FLOOR': {
      const ascendingFromFloor =
        torsoAngleDeg > th.burpeeFloorTorsoMaxDeg + 8 ||
        shoulderDrop < th.burpeeDropRatio * 0.85;
      if (ascendingFromFloor && now - runtime.phaseEnteredAt > 120) {
        runtime.phase = 'B_ASCEND';
        runtime.phaseEnteredAt = now;
      }
      break;
    }
    case 'B_ASCEND': {
      const nearUpright =
        torsoAngleDeg >= 58 && hip.y <= runtime.standingHipY + th.burpeeDropRatio * 0.45;
      if (nearUpright) {
        runtime.phase = 'B_JUMP_FINISH';
        runtime.phaseEnteredAt = now;
      }
      break;
    }
    case 'B_JUMP_FINISH': {
      const finishedExtension =
        hip.y <= runtime.standingHipY + th.burpeeStandMargin &&
        shoulder.y <= runtime.standingShoulderY + th.burpeeStandMargin &&
        torsoAngleDeg >= 65;
      if (finishedExtension && runtime.reachedFloor) {
        repCompleted = true;
        repDurationMs = runtime.repStartTime ? now - runtime.repStartTime : null;
        runtime.lastRepCompletedAt = now;
        runtime.repStartTime = null;
        runtime.reachedFloor = false;
        runtime.phase = 'B_STANDING';
        runtime.phaseEnteredAt = now;
      }
      break;
    }
  }

  return {
    phaseChanged: runtime.phase !== prevPhase,
    nextPhase: runtime.phase,
    repCompleted,
    repDurationMs,
    bodyDetected: true,
    telemetry,
  };
}

export function evaluateKettlebellSwingsFrame(
  landmarks: NormalizedLandmark[],
  runtime: TrackerRuntime,
  minVis: number,
  sensitivity: SensitivityLevel,
  now: number
): FrameEvaluationResult {
  const th = getDynamicThresholds(sensitivity);
  const shoulder = midpoint(
    getValidPoint(landmarks, LM.LEFT_SHOULDER, minVis),
    getValidPoint(landmarks, LM.RIGHT_SHOULDER, minVis)
  );
  const hip = midpoint(
    getValidPoint(landmarks, LM.LEFT_HIP, minVis),
    getValidPoint(landmarks, LM.RIGHT_HIP, minVis)
  );
  const knee = midpoint(
    getValidPoint(landmarks, LM.LEFT_KNEE, minVis),
    getValidPoint(landmarks, LM.RIGHT_KNEE, minVis)
  );
  const wrist = midpoint(
    getValidPoint(landmarks, LM.LEFT_WRIST, minVis),
    getValidPoint(landmarks, LM.RIGHT_WRIST, minVis)
  );

  if (!shoulder || !hip || !knee) {
    return {
      phaseChanged: false,
      nextPhase: runtime.phase,
      repCompleted: false,
      repDurationMs: null,
      bodyDetected: false,
      telemetry: {
        line1: 'Ángulo cadera: --°',
        line2: 'Muñecas: --',
        visibilityText: 'Muestra hombro-cadera-rodilla',
        visibilityTone: 'missing',
      },
    };
  }

  const hipHingeAngle = calculateAngleDegrees(shoulder, hip, knee);
  if (hipHingeAngle === null) {
    return {
      phaseChanged: false,
      nextPhase: runtime.phase,
      repCompleted: false,
      repDurationMs: null,
      bodyDetected: true,
      telemetry: {
        line1: 'Ángulo cadera: --°',
        line2: 'Muñecas: --',
        visibilityText: 'Calculando ángulo...',
        visibilityTone: 'partial',
      },
    };
  }

  const torsoHeight = Math.max(0.05, hip.y - shoulder.y);
  let wristElevationRatio = 0;
  let wristLabel = 'Sin detectar';
  if (wrist) {
    wristElevationRatio = (hip.y - wrist.y) / torsoHeight;
    if (wristElevationRatio >= 0.72) wristLabel = 'Nivel hombro';
    else if (wristElevationRatio >= 0.25) wristLabel = 'Nivel pecho';
    else if (wristElevationRatio >= -0.05) wristLabel = 'Nivel cadera';
    else wristLabel = 'Bajo cadera';
  }

  const telemetry: LiveTelemetry = {
    line1: `Ángulo cadera: ${Math.round(hipHingeAngle)}°`,
    line2: `Muñecas: ${wristLabel}`,
    visibilityText: wrist ? 'Bisagra + brazos OK' : 'Cadera OK (sin muñecas)',
    visibilityTone: wrist ? 'ok' : 'partial',
  };

  // Reiniciar ciclo atascado (>8s sin completar swing)
  if (runtime.repStartTime && now - runtime.repStartTime > 8000 && runtime.phase !== 'KB_READY') {
    runtime.hingePeakConfirmed = false;
    runtime.repStartTime = null;
    runtime.phase = 'KB_READY';
    runtime.phaseEnteredAt = now;
    return {
      phaseChanged: true,
      nextPhase: 'KB_READY',
      repCompleted: false,
      repDurationMs: null,
      bodyDetected: true,
      telemetry,
    };
  }

  const prevPhase = runtime.phase;
  let repCompleted = false;
  let repDurationMs: number | null = null;

  switch (runtime.phase) {
    case 'KB_READY': {
      const wristsLow = !wrist || wristElevationRatio <= 0.22;
      if (hipHingeAngle < th.kbHingeMaxDeg && wristsLow) {
        runtime.repStartTime = now;
        runtime.hingePeakConfirmed = true;
        runtime.minHingeAngleSeen = hipHingeAngle;
        runtime.phase = 'KB_HINGE';
        runtime.phaseEnteredAt = now;
      }
      break;
    }
    case 'KB_HINGE': {
      if (hipHingeAngle < runtime.minHingeAngleSeen) {
        runtime.minHingeAngleSeen = hipHingeAngle;
      }
      if (hipHingeAngle > runtime.minHingeAngleSeen + 14 && hipHingeAngle >= th.kbHingeMaxDeg + 4) {
        runtime.phase = 'KB_DRIVE';
        runtime.phaseEnteredAt = now;
      }
      break;
    }
    case 'KB_DRIVE': {
      if (hipHingeAngle < th.kbHingeMaxDeg - 4) {
        runtime.phase = 'KB_HINGE';
        runtime.phaseEnteredAt = now;
        break;
      }
      const hipLockedOut = hipHingeAngle >= th.kbLockoutMinDeg;
      const armsElevated = !wrist || wristElevationRatio >= th.kbWristDriveRatio;
      const antiBouncePassed = now - runtime.lastRepCompletedAt > 420;
      if (hipLockedOut && armsElevated && runtime.hingePeakConfirmed && antiBouncePassed) {
        repCompleted = true;
        repDurationMs = runtime.repStartTime ? now - runtime.repStartTime : null;
        runtime.lastRepCompletedAt = now;
        runtime.hingePeakConfirmed = false;
        runtime.repStartTime = null;
        runtime.minHingeAngleSeen = 180;
        runtime.phase = 'KB_READY';
        runtime.phaseEnteredAt = now;
      }
      break;
    }
  }

  return {
    phaseChanged: runtime.phase !== prevPhase,
    nextPhase: runtime.phase,
    repCompleted,
    repDurationMs,
    bodyDetected: true,
    telemetry,
  };
}

export function drawPoseSkeleton(
  canvas: HTMLCanvasElement,
  video: HTMLVideoElement,
  landmarks: NormalizedLandmark[] | null,
  phase: WorkoutPhase,
  minVis: number,
  drawEnabled: boolean
): void {
  const rect = canvas.getBoundingClientRect();
  const dpr = Math.min(window.devicePixelRatio || 1, 2);
  const targetW = Math.max(1, Math.floor(rect.width * dpr));
  const targetH = Math.max(1, Math.floor(rect.height * dpr));
  if (canvas.width !== targetW || canvas.height !== targetH) {
    canvas.width = targetW;
    canvas.height = targetH;
  }

  const ctx = canvas.getContext('2d');
  if (!ctx) return;
  ctx.clearRect(0, 0, canvas.width, canvas.height);

  if (!drawEnabled || !landmarks || landmarks.length === 0) return;

  const cw = canvas.width;
  const ch = canvas.height;
  const vw = video.videoWidth || cw;
  const vh = video.videoHeight || ch;
  const videoAspect = vw / vh;
  const canvasAspect = cw / ch;

  let drawW = cw;
  let drawH = ch;
  let offsetX = 0;
  let offsetY = 0;
  if (canvasAspect > videoAspect) {
    drawH = cw / videoAspect;
    offsetY = (ch - drawH) * 0.5;
  } else {
    drawW = ch * videoAspect;
    offsetX = (cw - drawW) * 0.5;
  }

  const toCanvas = (nx: number, ny: number) => ({
    x: offsetX + nx * drawW,
    y: offsetY + ny * drawH,
  });

  let boneColor = '#a3e635';
  if (phase.includes('SQUAT') || phase.includes('HINGE')) boneColor = '#22d3ee';
  else if (phase.includes('PLANK')) boneColor = '#fb7185';
  else if (phase.includes('ASCEND')) boneColor = '#fbbf24';
  else if (phase.includes('JUMP') || phase.includes('DRIVE')) boneColor = '#fb923c';

  ctx.lineCap = 'round';
  ctx.lineJoin = 'round';

  for (const [idxA, idxB] of SKELETON_CONNECTIONS) {
    const a = getValidPoint(landmarks, idxA, minVis);
    const b = getValidPoint(landmarks, idxB, minVis);
    if (!a || !b) continue;
    const ptA = toCanvas(a.x, a.y);
    const ptB = toCanvas(b.x, b.y);
    ctx.beginPath();
    ctx.moveTo(ptA.x, ptA.y);
    ctx.lineTo(ptB.x, ptB.y);
    ctx.strokeStyle = boneColor;
    ctx.lineWidth = Math.max(3, cw * 0.006);
    ctx.stroke();
  }

  for (const idx of TRACKED_JOINT_INDICES) {
    const kp = getValidPoint(landmarks, idx, minVis);
    if (!kp) continue;
    const pt = toCanvas(kp.x, kp.y);
    const radius = Math.max(4.5, cw * 0.0082);
    ctx.beginPath();
    ctx.arc(pt.x, pt.y, radius, 0, Math.PI * 2);
    ctx.fillStyle = '#090d16';
    ctx.fill();
    ctx.beginPath();
    ctx.arc(pt.x, pt.y, radius * 0.66, 0, Math.PI * 2);
    ctx.fillStyle = '#ffffff';
    ctx.fill();
  }
}
